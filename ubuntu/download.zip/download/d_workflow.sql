--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg110+2)
-- Dumped by pg_dump version 16.4 (Debian 16.4-1.pgdg110+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: d_workflow; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA d_workflow;


ALTER SCHEMA d_workflow OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assignment_retorno; Type: TABLE; Schema: d_workflow; Owner: postgres
--

CREATE TABLE d_workflow.assignment_retorno (
    id bigint NOT NULL,
    tenant_code character varying(50) NOT NULL,
    assignment_id character varying(50) NOT NULL,
    file_name text,
    file_hash character varying(128),
    storage_path text,
    retorno_state character varying(50) DEFAULT 'UPLOADED'::character varying NOT NULL,
    uploaded_by character varying(50),
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    validated_at timestamp with time zone,
    validation_result jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE d_workflow.assignment_retorno OWNER TO postgres;

--
-- Name: assignment_retorno_id_seq; Type: SEQUENCE; Schema: d_workflow; Owner: postgres
--

CREATE SEQUENCE d_workflow.assignment_retorno_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE d_workflow.assignment_retorno_id_seq OWNER TO postgres;

--
-- Name: assignment_retorno_id_seq; Type: SEQUENCE OWNED BY; Schema: d_workflow; Owner: postgres
--

ALTER SEQUENCE d_workflow.assignment_retorno_id_seq OWNED BY d_workflow.assignment_retorno.id;


--
-- Name: assignment_sync_job; Type: TABLE; Schema: d_workflow; Owner: postgres
--

CREATE TABLE d_workflow.assignment_sync_job (
    id bigint NOT NULL,
    tenant_code character varying(50) NOT NULL,
    assignment_id character varying(50) NOT NULL,
    job_type character varying(50) NOT NULL,
    sync_state character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_error text,
    correlation_id character varying(100),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE d_workflow.assignment_sync_job OWNER TO postgres;

--
-- Name: assignment_sync_job_id_seq; Type: SEQUENCE; Schema: d_workflow; Owner: postgres
--

CREATE SEQUENCE d_workflow.assignment_sync_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE d_workflow.assignment_sync_job_id_seq OWNER TO postgres;

--
-- Name: assignment_sync_job_id_seq; Type: SEQUENCE OWNED BY; Schema: d_workflow; Owner: postgres
--

ALTER SEQUENCE d_workflow.assignment_sync_job_id_seq OWNED BY d_workflow.assignment_sync_job.id;


--
-- Name: assignment_transitions; Type: TABLE; Schema: d_workflow; Owner: postgres
--

CREATE TABLE d_workflow.assignment_transitions (
    id bigint NOT NULL,
    tenant_code character varying(50) NOT NULL,
    assignment_id character varying(50) NOT NULL,
    workflow_event character varying(50) NOT NULL,
    from_state character varying(50),
    to_state character varying(50),
    actor_user_id character varying(50) NOT NULL,
    actor_role character varying(50),
    reason text,
    correlation_id character varying(100),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE d_workflow.assignment_transitions OWNER TO postgres;

--
-- Name: assignment_transitions_id_seq; Type: SEQUENCE; Schema: d_workflow; Owner: postgres
--

CREATE SEQUENCE d_workflow.assignment_transitions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE d_workflow.assignment_transitions_id_seq OWNER TO postgres;

--
-- Name: assignment_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: d_workflow; Owner: postgres
--

ALTER SEQUENCE d_workflow.assignment_transitions_id_seq OWNED BY d_workflow.assignment_transitions.id;


--
-- Name: assignments; Type: TABLE; Schema: d_workflow; Owner: postgres
--

CREATE TABLE d_workflow.assignments (
    assignment_id character varying(50) NOT NULL,
    tenant_code character varying(50) NOT NULL,
    workflow_state character varying(50) NOT NULL,
    workspace_state character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    retorno_state character varying(50) DEFAULT 'NONE'::character varying NOT NULL,
    sync_state character varying(50) DEFAULT 'NONE'::character varying NOT NULL,
    assigned_user_id character varying(50),
    assigned_role character varying(50),
    is_closed boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE d_workflow.assignments OWNER TO postgres;

--
-- Name: audit_events; Type: TABLE; Schema: d_workflow; Owner: postgres
--

CREATE TABLE d_workflow.audit_events (
    id bigint NOT NULL,
    event_type character varying(100) NOT NULL,
    tenant_code character varying(50) NOT NULL,
    assignment_id character varying(50) NOT NULL,
    actor_user_id character varying(50) NOT NULL,
    actor_role character varying(50),
    workflow_event character varying(50),
    from_state character varying(50),
    to_state character varying(50),
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    correlation_id character varying(100),
    source character varying(100),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE d_workflow.audit_events OWNER TO postgres;

--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: d_workflow; Owner: postgres
--

CREATE SEQUENCE d_workflow.audit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE d_workflow.audit_events_id_seq OWNER TO postgres;

--
-- Name: audit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: d_workflow; Owner: postgres
--

ALTER SEQUENCE d_workflow.audit_events_id_seq OWNED BY d_workflow.audit_events.id;


--
-- Name: outbox_messages; Type: TABLE; Schema: d_workflow; Owner: postgres
--

CREATE TABLE d_workflow.outbox_messages (
    id bigint NOT NULL,
    job_type character varying(50) NOT NULL,
    tenant_code character varying(50) NOT NULL,
    assignment_id character varying(50) NOT NULL,
    correlation_id character varying(100),
    idempotency_key character varying(255) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone
);


ALTER TABLE d_workflow.outbox_messages OWNER TO postgres;

--
-- Name: outbox_messages_id_seq; Type: SEQUENCE; Schema: d_workflow; Owner: postgres
--

CREATE SEQUENCE d_workflow.outbox_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE d_workflow.outbox_messages_id_seq OWNER TO postgres;

--
-- Name: outbox_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: d_workflow; Owner: postgres
--

ALTER SEQUENCE d_workflow.outbox_messages_id_seq OWNED BY d_workflow.outbox_messages.id;


--
-- Name: assignment_retorno id; Type: DEFAULT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_retorno ALTER COLUMN id SET DEFAULT nextval('d_workflow.assignment_retorno_id_seq'::regclass);


--
-- Name: assignment_sync_job id; Type: DEFAULT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_sync_job ALTER COLUMN id SET DEFAULT nextval('d_workflow.assignment_sync_job_id_seq'::regclass);


--
-- Name: assignment_transitions id; Type: DEFAULT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_transitions ALTER COLUMN id SET DEFAULT nextval('d_workflow.assignment_transitions_id_seq'::regclass);


--
-- Name: audit_events id; Type: DEFAULT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.audit_events ALTER COLUMN id SET DEFAULT nextval('d_workflow.audit_events_id_seq'::regclass);


--
-- Name: outbox_messages id; Type: DEFAULT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.outbox_messages ALTER COLUMN id SET DEFAULT nextval('d_workflow.outbox_messages_id_seq'::regclass);


--
-- Data for Name: assignment_retorno; Type: TABLE DATA; Schema: d_workflow; Owner: postgres
--

COPY d_workflow.assignment_retorno (id, tenant_code, assignment_id, file_name, file_hash, storage_path, retorno_state, uploaded_by, uploaded_at, validated_at, validation_result, metadata) FROM stdin;
\.


--
-- Data for Name: assignment_sync_job; Type: TABLE DATA; Schema: d_workflow; Owner: postgres
--

COPY d_workflow.assignment_sync_job (id, tenant_code, assignment_id, job_type, sync_state, started_at, finished_at, attempt_count, last_error, correlation_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: assignment_transitions; Type: TABLE DATA; Schema: d_workflow; Owner: postgres
--

COPY d_workflow.assignment_transitions (id, tenant_code, assignment_id, workflow_event, from_state, to_state, actor_user_id, actor_role, reason, correlation_id, metadata, occurred_at) FROM stdin;
1	sucre	144	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	6a292741-3fdf-4879-8a0b-b646941c0b6d	{"enlace_control_calidad": "https://www.youtube.com/?app=desktop&hl=es"}	2026-06-04 22:54:25.641972+00
6	sucre	144	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	1	coordinador	\N	488f67ed-372d-4ea6-b342-d8c28f329452	{}	2026-06-05 15:35:25.393027+00
7	sucre	144	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	87f896c3-6dd3-40da-a911-d3086ff1e600	{"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}	2026-06-05 15:46:03.296205+00
8	sucre	144	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	1	coordinador	\N	1d34f680-e616-45e8-8980-a6d92844f1b1	{}	2026-06-05 15:46:26.435628+00
9	sucre	144	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	fec63515-f32c-42e6-bbe6-d5e351e7045f	{"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}	2026-06-05 15:52:56.028816+00
10	sucre	144	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	66e7b8c1-9479-4e20-aa64-dbba06977e98	{}	2026-06-05 15:53:10.715182+00
11	sucre	145	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	8	reconocedor	\N	febe83d2-ad84-44ee-b371-0be891848623	{"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}	2026-06-05 17:16:19.01504+00
12	sucre	145	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	15	coordinador	\N	8fc67289-186d-48a8-b2c9-60a78acc03d1	{}	2026-06-05 17:17:45.200773+00
13	sucre	145	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	8	reconocedor	\N	1b8e4b72-1804-4d0f-889e-fa06fc9576ef	{"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}	2026-06-05 17:17:58.291045+00
15	sucre	145	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	b554bf44-26f4-4375-af7d-2497a12ddbb3	{}	2026-06-05 19:00:29.54488+00
16	sucre	146	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	18	reconocedor	\N	e80894d9-2bd0-4dc7-b269-ada0312d556b	{"enlace_control_calidad": "https://www.box.com/es-419/home"}	2026-06-05 20:31:58.47713+00
17	sucre	146	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	15	coordinador	\N	29c3a135-17ff-4509-99ab-78270498f897	{}	2026-06-05 20:32:25.729803+00
18	sucre	146	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	18	reconocedor	\N	a7b7e459-9b53-4848-838d-59983b990b75	{"enlace_control_calidad": "https://www.box.com/es-419/home"}	2026-06-05 20:32:39.675575+00
19	sucre	146	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	3d7cb264-0841-4ef3-aa2f-1e1d422e2790	{}	2026-06-05 20:33:10.628791+00
20	sucre	146	REASSIGN	APROBACION	APROBACION	15	coordinador	\N	a2a5a363-8ef0-4c4e-af04-9171764e9e70	{"target_user_id": "16"}	2026-06-09 12:49:05.327702+00
21	sucre	147	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	18	reconocedor	\N	898b5739-a99f-4cca-9fdb-7b83e753ff1f	{"enlace_control_calidad": "https://www.box.com/es-419/home"}	2026-06-09 14:31:04.073085+00
22	sucre	147	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	3d04dba7-aaee-40f0-815d-81e3d08f93c3	{}	2026-06-09 14:31:26.158939+00
23	sucre	147	REASSIGN	APROBACION	EN_CAMPO	15	coordinador	\N	7d2b0350-187d-417b-800f-10cd37ff1de7	{"target_user_id": "18"}	2026-06-09 14:31:59.430133+00
24	sucre	147	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	18	reconocedor	\N	8fd9f8b7-5978-4b94-a9b3-413cc7212d4b	{"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}	2026-06-09 14:42:04.149034+00
25	sucre	147	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	a47621e4-fdda-4ff9-83e2-12e529475be8	{}	2026-06-09 14:49:27.901681+00
26	sucre	147	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	c905b2ab-137a-459f-ac8d-e025f8e28ab0	{}	2026-06-09 14:56:08.16815+00
27	sucre	147	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	cd95a19f-376b-447b-a820-4884abf6c918	{}	2026-06-09 17:22:08.837559+00
28	sucre	147	START_SYNC	APROBACION	SINCRONIZACION	2	lider	\N	2223df37-f17b-49fb-8ee0-9778b763dbed	{}	2026-06-09 17:53:18.446021+00
29	sucre	148	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	fbce125f-0f4e-4d62-a46c-830c2387d381	{"enlace_control_calidad": "https://www.youtube.com/watch?v=V_xro1bcAuA"}	2026-06-09 18:48:35.906681+00
30	sucre	148	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	7728b68c-2893-4e79-b4d9-eec30cf0d8a5	{}	2026-06-09 18:48:48.109171+00
31	sucre	148	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	77fe199e-2f80-4020-a1ca-fb8a1bc2f46c	{"enlace_control_calidad": "https://mail.google.com/mail/u/0/#inbox"}	2026-06-09 18:49:01.897048+00
32	sucre	148	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	59b99f58-c3c3-4cb2-a538-efc5d4734083	{}	2026-06-09 18:49:08.081977+00
33	sucre	148	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	b9e36711-ec64-48b6-8856-d10ed2a97432	{"target_user_id": "6"}	2026-06-09 18:51:30.506521+00
34	sucre	148	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	21873b9c-afed-4358-9f06-70af5c034586	{"target_user_id": "6"}	2026-06-09 19:08:04.884562+00
35	sucre	148	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	99a9c6b9-0daa-4052-8da4-a2c254028de9	{"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}	2026-06-09 19:16:36.471805+00
36	sucre	148	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	a4db54bc-858c-4020-a5a5-01b816c81d62	{}	2026-06-09 19:16:50.125068+00
37	sucre	148	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	ebf06aaa-aa2d-48ec-855d-e53a2a6bac58	{"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}	2026-06-09 19:17:13.681191+00
38	sucre	148	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	22517205-37ce-44cc-8183-27dd29ae3bea	{}	2026-06-09 19:17:22.128628+00
39	sucre	148	RETURN_TO_FIELD	APROBACION	DEVUELTO	2	lider	\N	ba59ba14-250a-4f72-abed-cd5c991bd867	{}	2026-06-09 19:18:11.755926+00
40	sucre	148	RETURN_TO_FIELD	APROBACION	DEVUELTO	2	lider	\N	86412f91-d562-4c70-8255-79192c93772b	{}	2026-06-09 19:18:14.693556+00
41	sucre	148	RETURN_TO_FIELD	APROBACION	DEVUELTO	2	lider	\N	c965806d-0eda-45cc-8b98-3cd8addb7091	{}	2026-06-09 19:18:49.476834+00
42	sucre	148	RETURN_TO_FIELD	APROBACION	DEVUELTO	2	lider	\N	a5c48356-e601-424c-9cd6-dc08c1dfc89b	{}	2026-06-09 19:29:47.595567+00
43	sucre	148	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	189c78aa-834e-47d9-80e6-35b69d3fc943	{"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}	2026-06-09 19:30:43.89326+00
44	sucre	148	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2	lider	\N	38d43e3a-af6e-48d6-b870-1590767212a5	{}	2026-06-09 19:31:29.422201+00
45	sucre	148	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	913c1dda-6e50-4722-be1b-2b8aa128f031	{"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}	2026-06-09 20:05:44.604713+00
46	sucre	148	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	c65e4e99-9b41-4397-a61d-6439581a32eb	{}	2026-06-09 20:06:00.540548+00
47	sucre	148	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	96cbb139-b2be-4144-8436-19abb5067502	{"enlace_control_calidad": "https://www.youtube.com/watch?v=EKR2N52MY5k"}	2026-06-09 20:06:55.688714+00
48	sucre	148	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	ddb3ffb7-15a2-47cc-b9ba-5973b565d1cc	{}	2026-06-09 20:07:02.921273+00
49	sucre	148	START_SYNC	APROBACION	SINCRONIZACION	2	lider	\N	8c2b0e4e-a9bc-4e7a-90a8-0faecb6f1eda	{}	2026-06-09 20:07:28.792208+00
50	sucre	149	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	b1d2503d-3b20-46cf-8660-68fac7d3fd4d	{"enlace_control_calidad": "https://www.arbitrium.com.co/"}	2026-06-09 20:44:35.780395+00
51	sucre	149	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	df744b94-f30c-4785-ab44-613b0d621ee7	{}	2026-06-09 20:44:56.414262+00
52	sucre	149	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	312ff1ae-7797-45ad-bc20-079646feed19	{"enlace_control_calidad": "https://www.arbitrium.com.co/"}	2026-06-09 20:45:18.904448+00
53	sucre	149	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	79c413d2-7092-47b7-9226-e3befef702ec	{}	2026-06-09 20:45:59.66131+00
54	sucre	149	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	b921d348-c65e-4668-805a-408e54ef20c2	{"target_user_id": "19"}	2026-06-09 20:46:52.954113+00
55	sucre	149	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	19	reconocedor	\N	d568e27e-bc36-436b-bbb2-e1d58c3dfda0	{"enlace_control_calidad": "https://icons.getbootstrap.com/?q=text"}	2026-06-09 20:47:20.86445+00
56	sucre	149	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	ca03931b-7597-420f-a961-8b246af2ed7c	{}	2026-06-09 20:47:42.121677+00
57	sucre	149	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	19	reconocedor	\N	e5079d33-6047-4e0a-add2-3ffa43232af3	{"enlace_control_calidad": "https://icons.getbootstrap.com/?q=text"}	2026-06-09 20:47:55.071754+00
58	sucre	149	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	831cb68a-ecb7-4183-848a-c92356dc4ac0	{}	2026-06-09 20:48:17.94994+00
59	sucre	149	RETURN_TO_FIELD	APROBACION	DEVUELTO	2	lider	\N	c97c8842-bbad-439e-8857-75ded99e15e1	{}	2026-06-09 20:48:44.272744+00
60	sucre	149	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	19	reconocedor	\N	72d58e43-07f1-44b5-98d1-e40052e96886	{"enlace_control_calidad": "https://icons.getbootstrap.com/?q=text"}	2026-06-09 20:49:08.383684+00
61	sucre	149	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	713a806a-a2df-471b-9d03-41b47e6f3eae	{}	2026-06-09 20:49:25.648326+00
62	sucre	149	START_SYNC	APROBACION	SINCRONIZACION	2	lider	\N	e12c74ba-fe35-4452-a28b-a5a12969c6ec	{}	2026-06-09 20:49:34.787148+00
63	sucre	153	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	e24cc117-1d07-4a10-9bfa-c084bd5f7e6d	{"enlace_control_calidad": "https://www.arbitrium.com.co/"}	2026-06-09 20:56:38.839338+00
64	sucre	153	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	6bbc9536-6ad0-4577-8273-9f3ea0e2add4	{}	2026-06-09 21:02:57.787409+00
65	sucre	156	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	867aa3e1-4596-4b09-af19-d3df5119d0e1	{"enlace_control_calidad": "https://www.box.com/es-419/home"}	2026-06-10 19:15:30.606746+00
66	sucre	156	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	243d327e-8ee2-462f-a085-b6d872a3b1f2	{}	2026-06-10 19:17:48.469877+00
67	sucre	156	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	5a34acfa-a95a-49c7-b525-21fb4a237865	{"target_user_id": "6"}	2026-06-10 19:18:29.830916+00
68	sucre	156	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	ddba54eb-1bc3-455d-8e16-01f67a4b82ea	{"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}	2026-06-10 19:18:50.308931+00
69	sucre	156	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	e521b8ac-20b1-4093-86d6-5dd847cc9d78	{}	2026-06-10 19:18:59.009314+00
70	sucre	156	START_SYNC	APROBACION	SINCRONIZACION	2	lider	\N	7cd4b866-cf11-4073-ba49-b5c67b324b79	{}	2026-06-10 19:20:29.99005+00
71	sucre	157	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	2c9997c5-a640-4f5f-bd07-4487e0a092dc	{"enlace_control_calidad": "https://www.youtube.com/watch?v=V_xro1bcAuA"}	2026-06-10 21:54:39.68943+00
72	sucre	157	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	4271a0c3-7d11-4773-b5a3-b1de9f20992a	{}	2026-06-10 21:55:00.059703+00
73	sucre	157	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	8a274f32-77c2-4437-b20e-0bd69f548756	{"target_user_id": "6"}	2026-06-10 21:55:19.113231+00
74	sucre	157	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	e3e15309-ca8d-4498-bf85-4a88076d19b7	{"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}	2026-06-10 21:55:31.360887+00
75	sucre	157	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	5eb77f81-528b-43a8-bb3e-218ef212edf1	{}	2026-06-10 21:55:51.682052+00
76	sucre	157	START_SYNC	APROBACION	SINCRONIZACION	2	lider	\N	88e51a11-f71d-4f92-895a-2a146ebf4d97	{}	2026-06-10 21:56:15.114202+00
77	sucre	158	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	6198e412-1fc2-479c-adaa-e939bf66b19b	{"enlace_control_calidad": "https://www.youtube.com/?app=desktop&hl=es"}	2026-06-11 14:05:13.03789+00
78	sucre	158	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	9be2eae6-ae48-4bc6-a3df-04b31de189d1	{"enlace_control_calidad": "https://www.youtube.com/?app=desktop&hl=es"}	2026-06-11 22:25:32.764177+00
79	sucre	158	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	f59186e6-ea4b-4d4e-b590-c0090f36ee4f	{}	2026-06-11 22:32:32.505206+00
80	sucre	158	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	6	reconocedor	\N	c8a45bc2-a40d-447a-855d-6d60933ec5dc	{"enlace_control_calidad": "https://www.box.com/es-419/home"}	2026-06-12 14:19:17.398196+00
81	sucre	158	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	64416325-7e35-4de1-88bf-52bbab9440a7	{}	2026-06-12 15:57:14.284881+00
82	sucre	158	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	87e0a035-9d3a-4241-8cc9-c4c33514884e	{"target_user_id": "19"}	2026-06-12 15:57:48.129731+00
83	sucre	158	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	19	reconocedor	\N	3ccb0f67-8570-4e22-b77d-5006a2805f24	{"enlace_control_calidad": "https://www.anthropic.com/learning"}	2026-06-12 16:00:42.112255+00
84	sucre	158	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	02ce94df-328a-4d64-af62-10b1a6e736e3	{}	2026-06-12 16:01:03.329016+00
85	sucre	158	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	19	reconocedor	\N	be0d46a4-d85b-434e-92b2-79c304d43dc8	{"enlace_control_calidad": "https://www.anthropic.com/lean"}	2026-06-12 16:01:45.929199+00
86	sucre	158	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	30df2a98-7d08-49f9-9e5b-b217c7be3a59	{}	2026-06-12 17:40:51.293157+00
87	sucre	158	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	19	reconocedor	\N	90881bb5-1f33-47d0-b160-c0ac22ee5068	{"enlace_control_calidad": "https://www.anthropic.com/learn-updated"}	2026-06-12 17:50:20.48503+00
88	sucre	158	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	9	coordinador	\N	e4b0815a-b18a-4034-b808-a605a2c9d016	{}	2026-06-12 18:11:03.93638+00
89	sucre	158	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	19	reconocedor	\N	5f2d0626-1d5f-4765-9757-ae7494361f42	{"enlace_control_calidad": "https://www.anthropic.com/lean"}	2026-06-12 18:24:27.560338+00
90	sucre	158	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	799bedd4-9a70-415d-8d97-2f6301a1a89f	{}	2026-06-12 18:24:50.091341+00
91	sucre	158	START_SYNC	APROBACION	SINCRONIZACION	2	lider	\N	2d57d24e-5717-455f-b361-c025527a8ff2	{}	2026-06-12 18:47:34.718545+00
92	sucre	159	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	0f1dff3a-dff5-43fd-93ea-1fd50850a148	{"enlace_control_calidad": "https://www.box.com/es-419/home"}	2026-06-12 21:07:08.527603+00
93	sucre	159	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	e41281a7-c193-4752-8a65-a4f0617edbda	{}	2026-06-16 13:17:16.014842+00
94	sucre	159	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	5367e0e2-e78a-4c02-b09d-d8f587baf431	{"target_user_id": "6"}	2026-06-16 13:58:58.940964+00
95	sucre	159	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	6	reconocedor	\N	b4c4ca93-5c22-49cd-929f-c9a4bd89728d	{"enlace_control_calidad": "https://desarrollo.arbimaps.com/"}	2026-06-16 14:51:05.15665+00
96	sucre	3	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	23	reconocedor	\N	7b5c33c1-e526-4902-9fd9-31c4bc72173c	{"enlace_control_calidad": "https://www.youtube.com/watch?v=GBRnn18YP-I"}	2026-07-24 15:17:14.990605+00
97	sucre	3	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	f523ebb9-efec-4078-9fc8-bbc14700f46f	{}	2026-07-24 15:19:08.734152+00
98	sucre	3	REASSIGN	APROBACION	EN_CAMPO	9	coordinador	\N	374ab00f-c262-46ad-b9c5-1ae060707715	{"target_user_id": "19"}	2026-07-24 15:47:56.515575+00
99	sucre	3	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	19	reconocedor	\N	97c3bb96-de64-4ac1-b5d6-ea5588f65c7e	{"enlace_control_calidad": "https://www.facebook.com/reel/1024836393690687"}	2026-07-24 15:55:48.739747+00
100	sucre	3	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	d15e1f3c-f484-489d-9817-8367accb1bd4	{}	2026-07-24 16:53:35.345099+00
101	sucre	3	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	9b737060-acf4-44cc-a1ee-17805241ce16	{}	2026-07-24 16:53:43.965661+00
102	sucre	3	APPROVE	CONTROL_CALIDAD_1	APROBACION	9	coordinador	\N	2f354786-d40a-40de-8c8c-cf197bb7f989	{}	2026-07-24 16:55:06.891358+00
103	sucre	5	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	18	reconocedor	\N	7dd9b90a-d9ed-4964-8348-fb4d26dac580	{"enlace_control_calidad": "https://www.youtube.com/watch?v=eTLh1JuFqCM"}	2026-07-24 19:42:22.632983+00
104	sucre	5	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	dd61514c-1f37-4f7c-bf45-15e27a7e4a74	{}	2026-07-24 19:42:42.1567+00
105	sucre	5	REASSIGN	APROBACION	EN_CAMPO	15	coordinador	\N	2c240675-669a-4b6f-8cc9-43cdebc35850	{"target_user_id": "19"}	2026-07-24 19:50:46.365225+00
106	sucre	5	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	19	reconocedor	\N	6bf294c2-448c-4c55-8ca9-f28cc68885fe	{"enlace_control_calidad": "http://192.168.0.57/neiva/bienvenida.php"}	2026-07-24 20:20:59.738326+00
107	sucre	5	APPROVE	CONTROL_CALIDAD_1	APROBACION	15	coordinador	\N	aab984b9-8705-4a0a-a85e-4ec1037b2563	{}	2026-07-24 20:21:17.350014+00
108	sucre	4	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	25	reconocedor	\N	5a02d33e-28a0-43e7-98c3-ef2ca97f62ce	{"enlace_control_calidad": "https://www.youtube.com/watch?v=eTLh1JuFqCM"}	2026-07-27 14:52:04.695114+00
109	sucre	4	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	e6a6df72-f923-4b0c-8a81-22a1de1dd46a	{}	2026-07-27 14:52:30.734897+00
110	sucre	4	REASSIGN	APROBACION	EN_CAMPO	1	coordinador	\N	daaaa502-0cff-4b7b-b1be-3d9376382974	{"target_user_id": "16"}	2026-07-27 14:54:26.536533+00
111	sucre	4	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	16	reconocedor	\N	d05f0281-192b-41ac-9fd5-abbbb03bb14e	{"enlace_control_calidad": "https://desarrolloarbimapps.atlassian.net/issues/?filter=-1"}	2026-07-27 14:55:29.039697+00
112	sucre	4	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	05e75774-9119-4e2d-89a1-2e5f55616464	{}	2026-07-27 14:55:52.80797+00
113	sucre	6	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	25	reconocedor	\N	f3f5b7d3-e435-4436-9079-588256404118	{"enlace_control_calidad": "https://www.youtube.com/watch?v=eTLh1JuFqCM"}	2026-07-27 15:49:30.010348+00
114	sucre	6	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	29569ab2-7f14-4d59-8382-612d786ab0bd	{}	2026-07-27 16:38:52.015338+00
115	sucre	6	REASSIGN	APROBACION	EN_CAMPO	1	coordinador	\N	8867d09a-efcd-44e5-b687-9e383d43270a	{"target_user_id": "19"}	2026-07-27 16:39:16.122523+00
116	sucre	7	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	25	reconocedor	\N	dcb9f522-23c4-4a6e-aa2d-053676f38f83	{"enlace_control_calidad": "https://github.com/MasterErrorCLONE04/Arbimaps_rework"}	2026-07-27 20:05:08.568732+00
117	sucre	7	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	a12c7542-b866-416e-85c9-bde0cdeea083	{}	2026-07-27 20:05:47.64866+00
118	sucre	7	REASSIGN	APROBACION	EN_CAMPO	1	coordinador	\N	b527b22b-6a7b-469e-b4b4-96c447ce1dd1	{"target_user_id": "19"}	2026-07-27 20:06:11.622698+00
119	sucre	8	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	25	reconocedor	\N	26d0872f-8990-448d-aef2-0ddb87669132	{"enlace_control_calidad": "https://www.youtube.com/watch?v=ith_yAAZqrk"}	2026-07-27 20:51:36.164678+00
120	sucre	8	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	8ed538c2-7080-472d-80c0-4a7f59542a75	{}	2026-07-27 20:52:10.672497+00
121	sucre	8	REASSIGN	APROBACION	EN_CAMPO	1	coordinador	\N	57405d28-50c8-49c6-8fa9-338dcfa24b75	{"target_user_id": "19"}	2026-07-27 20:52:32.065386+00
122	sucre	8	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	19	reconocedor	\N	ad88aa11-704d-44cf-84a5-031f045308c8	{"enlace_control_calidad": "https://github.com/MasterErrorCLONE04/Arbimaps_rework"}	2026-07-27 20:53:25.204343+00
123	sucre	8	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	a2603014-3e3e-424e-816a-bf5c5f25c412	{}	2026-07-27 20:53:46.803652+00
124	sucre	10	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	25	reconocedor	\N	04c866e6-382a-485b-9e21-8fcc58eb1778	{"enlace_control_calidad": "https://github.com/MasterErrorCLONE04/Develop"}	2026-07-28 15:17:48.289005+00
125	sucre	10	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	cf9e0d35-6c47-4cf4-861d-96e78ffd8721	{}	2026-07-28 15:18:04.488346+00
126	sucre	10	REASSIGN	APROBACION	EN_CAMPO	1	coordinador	\N	5d4779e3-2bfe-4c1c-bac1-9ba2f6c300c2	{"target_user_id": "19"}	2026-07-28 15:18:20.364807+00
127	sucre	10	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	19	reconocedor	\N	f42a8aeb-12c3-45ee-ac2e-387a270b48c7	{"enlace_control_calidad": "https://desarrolloarbimapps.atlassian.net/issues/?filter=-1"}	2026-07-28 15:18:45.499047+00
128	sucre	10	APPROVE	CONTROL_CALIDAD_1	APROBACION	1	coordinador	\N	f56bff5d-dd19-46ef-88d0-eda2b71633de	{}	2026-07-28 15:19:12.731262+00
\.


--
-- Data for Name: assignments; Type: TABLE DATA; Schema: d_workflow; Owner: postgres
--

COPY d_workflow.assignments (assignment_id, tenant_code, workflow_state, workspace_state, retorno_state, sync_state, assigned_user_id, assigned_role, is_closed, version, metadata, created_at, updated_at) FROM stdin;
148	sucre	SINCRONIZACION	READY	NONE	RUNNING	6	reconocedor	f	27	{}	2026-06-09 18:48:35.899163+00	2026-06-09 20:07:28.789737+00
144	sucre	APROBACION	READY	NONE	PENDING	6	reconocedor	f	7	{}	2026-06-04 22:54:25.629611+00	2026-06-05 15:53:10.71395+00
149	sucre	SINCRONIZACION	READY	NONE	RUNNING	19	reconocedor	f	15	{}	2026-06-09 20:44:35.774148+00	2026-06-09 20:49:34.784748+00
146	sucre	EN_CAMPO	PENDING	NONE	NONE	16	reconocedor	f	7	{}	2026-06-05 20:31:58.471922+00	2026-06-09 14:19:45.157685+00
145	sucre	EN_CAMPO	READY	NONE	PENDING	8	reconocedor	f	7	{}	2026-06-05 17:16:19.007692+00	2026-06-09 14:20:06.510094+00
153	sucre	APROBACION	READY	NONE	PENDING	6	reconocedor	f	3	{}	2026-06-09 20:56:38.83643+00	2026-06-09 21:02:57.785093+00
156	sucre	SINCRONIZACION	READY	NONE	RUNNING	6	reconocedor	f	8	{}	2026-06-10 19:15:30.591939+00	2026-06-10 19:20:29.98759+00
147	sucre	SINCRONIZACION	READY	NONE	RUNNING	18	reconocedor	f	12	{}	2026-06-09 14:31:04.0707+00	2026-06-09 17:53:18.440951+00
157	sucre	SINCRONIZACION	READY	NONE	RUNNING	6	reconocedor	f	8	{}	2026-06-10 21:54:39.683118+00	2026-06-10 21:56:15.112405+00
158	sucre	SINCRONIZACION	READY	NONE	RUNNING	19	reconocedor	f	18	{}	2026-06-11 14:05:13.031349+00	2026-06-12 18:47:34.715814+00
159	sucre	CONTROL_CALIDAD_1	READY	NONE	NONE	6	reconocedor	f	6	{}	2026-06-12 21:07:08.523003+00	2026-06-16 14:51:05.145042+00
3	sucre	APROBACION	READY	NONE	PENDING	19	reconocedor	f	11	{}	2026-07-24 15:17:14.986454+00	2026-07-24 16:55:06.888114+00
5	sucre	APROBACION	READY	NONE	PENDING	19	reconocedor	f	7	{}	2026-07-24 19:42:22.627017+00	2026-07-24 20:21:17.349315+00
4	sucre	APROBACION	READY	NONE	PENDING	16	reconocedor	f	7	{}	2026-07-27 14:52:04.689636+00	2026-07-27 14:55:52.807312+00
6	sucre	EN_CAMPO	PENDING	NONE	NONE	19	reconocedor	f	4	{}	2026-07-27 15:49:30.007108+00	2026-07-27 16:39:16.121753+00
7	sucre	EN_CAMPO	PENDING	NONE	NONE	19	reconocedor	f	4	{}	2026-07-27 20:05:08.561976+00	2026-07-27 20:06:11.621977+00
8	sucre	APROBACION	READY	NONE	PENDING	19	reconocedor	f	7	{}	2026-07-27 20:51:36.160853+00	2026-07-27 20:53:46.803156+00
10	sucre	APROBACION	READY	NONE	PENDING	19	reconocedor	f	7	{}	2026-07-28 15:17:48.284612+00	2026-07-28 15:19:12.730179+00
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: d_workflow; Owner: postgres
--

COPY d_workflow.audit_events (id, event_type, tenant_code, assignment_id, actor_user_id, actor_role, workflow_event, from_state, to_state, occurred_at, correlation_id, source, metadata) FROM stdin;
1	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	144	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-04 22:54:25.641972+00	6a292741-3fdf-4879-8a0b-b646941c0b6d	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/?app=desktop&hl=es"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
2	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	144	1	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-05 15:35:25.393027+00	488f67ed-372d-4ea6-b342-d8c28f329452	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
3	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	144	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-05 15:46:03.296205+00	87f896c3-6dd3-40da-a911-d3086ff1e600	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
4	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	144	1	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-05 15:46:26.435628+00	1d34f680-e616-45e8-8980-a6d92844f1b1	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
5	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	144	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-05 15:52:56.028816+00	fec63515-f32c-42e6-bbe6-d5e351e7045f	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
6	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	144	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-05 15:53:10.715182+00	66e7b8c1-9479-4e20-aa64-dbba06977e98	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
7	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	145	8	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-05 17:16:19.01504+00	febe83d2-ad84-44ee-b371-0be891848623	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
8	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	145	15	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-05 17:17:45.200773+00	8fc67289-186d-48a8-b2c9-60a78acc03d1	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
9	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	145	8	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-05 17:17:58.291045+00	1b8e4b72-1804-4d0f-889e-fa06fc9576ef	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://account.box.com/login?_gl=1*9ze9zn*_gcl_au*ODMwMDQ4OTMyLjE3ODA2NzQyMDg."}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
10	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	145	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-05 17:21:52.274167+00	16957dfe-e1af-4213-9f71-72f8ed88984c	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
11	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	145	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-05 19:00:29.54488+00	b554bf44-26f4-4375-af7d-2497a12ddbb3	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
12	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	146	18	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-05 20:31:58.47713+00	e80894d9-2bd0-4dc7-b269-ada0312d556b	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.box.com/es-419/home"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
13	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	146	15	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-05 20:32:25.729803+00	29c3a135-17ff-4509-99ab-78270498f897	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
14	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	146	18	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-05 20:32:39.675575+00	a7b7e459-9b53-4848-838d-59983b990b75	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.box.com/es-419/home"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
15	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	146	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-05 20:33:10.628791+00	3d7cb264-0841-4ef3-aa2f-1e1d422e2790	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
16	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	146	15	coordinador	REASSIGN	APROBACION	APROBACION	2026-06-09 12:49:05.327702+00	a2a5a363-8ef0-4c4e-af04-9171764e9e70	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "16"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
17	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	146	15	coordinador	REASSIGN	APROBACION	APROBACION	2026-06-09 12:49:05.327702+00	a2a5a363-8ef0-4c4e-af04-9171764e9e70	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "16"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
18	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	146	15	coordinador	REASSIGN	APROBACION	APROBACION	2026-06-09 12:49:05.327702+00	a2a5a363-8ef0-4c4e-af04-9171764e9e70	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "16"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
19	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	18	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-09 14:31:04.073085+00	898b5739-a99f-4cca-9fdb-7b83e753ff1f	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.box.com/es-419/home"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
20	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 14:31:26.158939+00	3d04dba7-aaee-40f0-815d-81e3d08f93c3	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
21	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	147	15	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 14:31:59.430133+00	7d2b0350-187d-417b-800f-10cd37ff1de7	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "18"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
22	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	15	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 14:31:59.430133+00	7d2b0350-187d-417b-800f-10cd37ff1de7	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "18"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
23	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	147	15	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 14:31:59.430133+00	7d2b0350-187d-417b-800f-10cd37ff1de7	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "18"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
24	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	18	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-09 14:42:04.149034+00	8fd9f8b7-5978-4b94-a9b3-413cc7212d4b	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
25	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 14:49:27.901681+00	a47621e4-fdda-4ff9-83e2-12e529475be8	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
26	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 14:56:08.16815+00	c905b2ab-137a-459f-ac8d-e025f8e28ab0	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
27	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 17:22:08.837559+00	cd95a19f-376b-447b-a820-4884abf6c918	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
28	AuditEventType.ASSIGNMENT_SYNC_STARTED	sucre	147	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-09 17:53:18.446021+00	2223df37-f17b-49fb-8ee0-9778b763dbed	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
29	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	147	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-09 17:53:18.446021+00	2223df37-f17b-49fb-8ee0-9778b763dbed	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
30	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-09 18:48:35.906681+00	fbce125f-0f4e-4d62-a46c-830c2387d381	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=V_xro1bcAuA"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
31	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-09 18:48:48.109171+00	7728b68c-2893-4e79-b4d9-eec30cf0d8a5	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
32	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 18:49:01.897048+00	77fe199e-2f80-4020-a1ca-fb8a1bc2f46c	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://mail.google.com/mail/u/0/#inbox"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
33	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 18:49:08.081977+00	59b99f58-c3c3-4cb2-a538-efc5d4734083	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
34	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	148	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 18:51:30.506521+00	b9e36711-ec64-48b6-8856-d10ed2a97432	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
35	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 18:51:30.506521+00	b9e36711-ec64-48b6-8856-d10ed2a97432	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
36	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	148	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 18:51:30.506521+00	b9e36711-ec64-48b6-8856-d10ed2a97432	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
37	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	148	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 19:08:04.884562+00	21873b9c-afed-4358-9f06-70af5c034586	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
38	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 19:08:04.884562+00	21873b9c-afed-4358-9f06-70af5c034586	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
39	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	148	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 19:08:04.884562+00	21873b9c-afed-4358-9f06-70af5c034586	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
40	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-09 19:16:36.471805+00	99a9c6b9-0daa-4052-8da4-a2c254028de9	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
41	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-09 19:16:50.125068+00	a4db54bc-858c-4020-a5a5-01b816c81d62	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
42	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 19:17:13.681191+00	ebf06aaa-aa2d-48ec-855d-e53a2a6bac58	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
43	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 19:17:22.128628+00	22517205-37ce-44cc-8183-27dd29ae3bea	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
44	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	2	lider	RETURN_TO_FIELD	APROBACION	DEVUELTO	2026-06-09 19:18:11.755926+00	ba59ba14-250a-4f72-abed-cd5c991bd867	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
45	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	2	lider	RETURN_TO_FIELD	APROBACION	DEVUELTO	2026-06-09 19:18:14.693556+00	86412f91-d562-4c70-8255-79192c93772b	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
46	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	2	lider	RETURN_TO_FIELD	APROBACION	DEVUELTO	2026-06-09 19:18:49.476834+00	c965806d-0eda-45cc-8b98-3cd8addb7091	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
47	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	2	lider	RETURN_TO_FIELD	APROBACION	DEVUELTO	2026-06-09 19:29:47.595567+00	a5c48356-e601-424c-9cd6-dc08c1dfc89b	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
48	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 19:30:43.89326+00	189c78aa-834e-47d9-80e6-35b69d3fc943	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
49	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	2	lider	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-09 19:31:29.422201+00	38d43e3a-af6e-48d6-b870-1590767212a5	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
50	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 20:05:44.604713+00	913c1dda-6e50-4722-be1b-2b8aa128f031	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
51	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-09 20:06:00.540548+00	c65e4e99-9b41-4397-a61d-6439581a32eb	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
52	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 20:06:55.688714+00	96cbb139-b2be-4144-8436-19abb5067502	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=EKR2N52MY5k"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
53	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 20:07:02.921273+00	ddb3ffb7-15a2-47cc-b9ba-5973b565d1cc	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
54	AuditEventType.ASSIGNMENT_SYNC_STARTED	sucre	148	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-09 20:07:28.792208+00	8c2b0e4e-a9bc-4e7a-90a8-0faecb6f1eda	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
55	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	148	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-09 20:07:28.792208+00	8c2b0e4e-a9bc-4e7a-90a8-0faecb6f1eda	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
56	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-09 20:44:35.780395+00	b1d2503d-3b20-46cf-8660-68fac7d3fd4d	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.arbitrium.com.co/"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
57	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-09 20:44:56.414262+00	df744b94-f30c-4785-ab44-613b0d621ee7	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
58	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 20:45:18.904448+00	312ff1ae-7797-45ad-bc20-079646feed19	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.arbitrium.com.co/"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
59	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 20:45:59.66131+00	79c413d2-7092-47b7-9226-e3befef702ec	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
60	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	149	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 20:46:52.954113+00	b921d348-c65e-4668-805a-408e54ef20c2	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
61	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 20:46:52.954113+00	b921d348-c65e-4668-805a-408e54ef20c2	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
62	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	149	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-09 20:46:52.954113+00	b921d348-c65e-4668-805a-408e54ef20c2	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
63	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	19	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-09 20:47:20.86445+00	d568e27e-bc36-436b-bbb2-e1d58c3dfda0	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://icons.getbootstrap.com/?q=text"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
64	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-09 20:47:42.121677+00	ca03931b-7597-420f-a961-8b246af2ed7c	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
65	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	19	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 20:47:55.071754+00	e5079d33-6047-4e0a-add2-3ffa43232af3	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://icons.getbootstrap.com/?q=text"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
66	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 20:48:17.94994+00	831cb68a-ecb7-4183-848a-c92356dc4ac0	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
67	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	2	lider	RETURN_TO_FIELD	APROBACION	DEVUELTO	2026-06-09 20:48:44.272744+00	c97c8842-bbad-439e-8857-75ded99e15e1	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
68	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	19	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-09 20:49:08.383684+00	72d58e43-07f1-44b5-98d1-e40052e96886	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://icons.getbootstrap.com/?q=text"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
69	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 20:49:25.648326+00	713a806a-a2df-471b-9d03-41b47e6f3eae	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
70	AuditEventType.ASSIGNMENT_SYNC_STARTED	sucre	149	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-09 20:49:34.787148+00	e12c74ba-fe35-4452-a28b-a5a12969c6ec	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
71	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	149	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-09 20:49:34.787148+00	e12c74ba-fe35-4452-a28b-a5a12969c6ec	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
72	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	153	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-09 20:56:38.839338+00	e24cc117-1d07-4a10-9bfa-c084bd5f7e6d	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.arbitrium.com.co/"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
73	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	153	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-09 21:02:57.787409+00	6bbc9536-6ad0-4577-8273-9f3ea0e2add4	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
74	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	156	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-10 19:15:30.606746+00	867aa3e1-4596-4b09-af19-d3df5119d0e1	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.box.com/es-419/home"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
75	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	156	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-10 19:17:48.469877+00	243d327e-8ee2-462f-a085-b6d872a3b1f2	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
76	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	156	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-10 19:18:29.830916+00	5a34acfa-a95a-49c7-b525-21fb4a237865	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
77	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	156	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-10 19:18:29.830916+00	5a34acfa-a95a-49c7-b525-21fb4a237865	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
78	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	156	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-10 19:18:29.830916+00	5a34acfa-a95a-49c7-b525-21fb4a237865	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
79	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	156	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-10 19:18:50.308931+00	ddba54eb-1bc3-455d-8e16-01f67a4b82ea	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
80	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	156	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-10 19:18:59.009314+00	e521b8ac-20b1-4093-86d6-5dd847cc9d78	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
81	AuditEventType.ASSIGNMENT_SYNC_STARTED	sucre	156	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-10 19:20:29.99005+00	7cd4b866-cf11-4073-ba49-b5c67b324b79	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
82	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	156	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-10 19:20:29.99005+00	7cd4b866-cf11-4073-ba49-b5c67b324b79	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
83	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	157	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-10 21:54:39.68943+00	2c9997c5-a640-4f5f-bd07-4487e0a092dc	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=V_xro1bcAuA"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
84	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	157	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-10 21:55:00.059703+00	4271a0c3-7d11-4773-b5a3-b1de9f20992a	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
85	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	157	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-10 21:55:19.113231+00	8a274f32-77c2-4437-b20e-0bd69f548756	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
86	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	157	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-10 21:55:19.113231+00	8a274f32-77c2-4437-b20e-0bd69f548756	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
87	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	157	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-10 21:55:19.113231+00	8a274f32-77c2-4437-b20e-0bd69f548756	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
88	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	157	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-10 21:55:31.360887+00	e3e15309-ca8d-4498-bf85-4a88076d19b7	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=SaVMFl6MGq8&list=RDyKlmw_6Kufw&index=27"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
89	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	157	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-10 21:55:51.682052+00	5eb77f81-528b-43a8-bb3e-218ef212edf1	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
90	AuditEventType.ASSIGNMENT_SYNC_STARTED	sucre	157	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-10 21:56:15.114202+00	88e51a11-f71d-4f92-895a-2a146ebf4d97	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
91	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	157	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-10 21:56:15.114202+00	88e51a11-f71d-4f92-895a-2a146ebf4d97	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
92	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-11 14:05:13.03789+00	6198e412-1fc2-479c-adaa-e939bf66b19b	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/?app=desktop&hl=es"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
93	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-11 22:25:32.764177+00	9be2eae6-ae48-4bc6-a3df-04b31de189d1	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/?app=desktop&hl=es"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
94	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-11 22:32:32.505206+00	f59186e6-ea4b-4d4e-b590-c0090f36ee4f	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
95	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	6	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-12 14:19:17.398196+00	c8a45bc2-a40d-447a-855d-6d60933ec5dc	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.box.com/es-419/home"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
96	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-12 15:57:14.284881+00	64416325-7e35-4de1-88bf-52bbab9440a7	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
97	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	158	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-12 15:57:48.129731+00	87e0a035-9d3a-4241-8cc9-c4c33514884e	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
98	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-12 15:57:48.129731+00	87e0a035-9d3a-4241-8cc9-c4c33514884e	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
99	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	158	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-12 15:57:48.129731+00	87e0a035-9d3a-4241-8cc9-c4c33514884e	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
100	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	19	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-12 16:00:42.112255+00	3ccb0f67-8570-4e22-b77d-5006a2805f24	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.anthropic.com/learning"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
101	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-12 16:01:03.329016+00	02ce94df-328a-4d64-af62-10b1a6e736e3	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
102	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	19	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-12 16:01:45.929199+00	be0d46a4-d85b-434e-92b2-79c304d43dc8	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.anthropic.com/lean"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
103	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-12 17:40:51.293157+00	30df2a98-7d08-49f9-9e5b-b217c7be3a59	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
104	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	19	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-12 17:50:20.48503+00	90881bb5-1f33-47d0-b160-c0ac22ee5068	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.anthropic.com/learn-updated"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
105	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	9	coordinador	RETURN_TO_FIELD	CONTROL_CALIDAD_1	DEVUELTO	2026-06-12 18:11:03.93638+00	e4b0815a-b18a-4034-b808-a605a2c9d016	workflow.service	{"precondition_hooks": [], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
106	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	19	reconocedor	SUBMIT_FOR_QA	DEVUELTO	CONTROL_CALIDAD_1	2026-06-12 18:24:27.560338+00	5f2d0626-1d5f-4765-9757-ae7494361f42	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.anthropic.com/lean"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
107	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-12 18:24:50.091341+00	799bedd4-9a70-415d-8d97-2f6301a1a89f	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
108	AuditEventType.ASSIGNMENT_SYNC_STARTED	sucre	158	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-12 18:47:34.718545+00	2d57d24e-5717-455f-b361-c025527a8ff2	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
109	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	158	2	lider	START_SYNC	APROBACION	SINCRONIZACION	2026-06-12 18:47:34.718545+00	2d57d24e-5717-455f-b361-c025527a8ff2	workflow.service	{"precondition_hooks": ["workspace_ready", "retorno_validated"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
110	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	159	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-12 21:07:08.527603+00	0f1dff3a-dff5-43fd-93ea-1fd50850a148	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.box.com/es-419/home"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
111	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	159	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-06-16 13:17:16.014842+00	e41281a7-c193-4752-8a65-a4f0617edbda	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
112	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	159	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-16 13:58:58.940964+00	5367e0e2-e78a-4c02-b09d-d8f587baf431	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
113	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	159	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-16 13:58:58.940964+00	5367e0e2-e78a-4c02-b09d-d8f587baf431	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
114	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	159	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-06-16 13:58:58.940964+00	5367e0e2-e78a-4c02-b09d-d8f587baf431	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "6"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
115	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	159	6	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-06-16 14:51:05.15665+00	b4c4ca93-5c22-49cd-929f-c9a4bd89728d	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://desarrollo.arbimaps.com/"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
116	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	3	23	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-24 15:17:14.990605+00	7b5c33c1-e526-4902-9fd9-31c4bc72173c	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=GBRnn18YP-I"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
117	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	3	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-24 15:19:08.734152+00	f523ebb9-efec-4078-9fc8-bbc14700f46f	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
118	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	3	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-24 15:47:56.515575+00	374ab00f-c262-46ad-b9c5-1ae060707715	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
119	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	3	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-24 15:47:56.515575+00	374ab00f-c262-46ad-b9c5-1ae060707715	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
120	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	3	9	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-24 15:47:56.515575+00	374ab00f-c262-46ad-b9c5-1ae060707715	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
121	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	3	19	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-24 15:55:48.739747+00	97c3bb96-de64-4ac1-b5d6-ea5588f65c7e	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.facebook.com/reel/1024836393690687"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
122	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	3	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-24 16:53:35.345099+00	d15e1f3c-f484-489d-9817-8367accb1bd4	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
123	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	3	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-24 16:53:43.965661+00	9b737060-acf4-44cc-a1ee-17805241ce16	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
124	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	3	9	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-24 16:55:06.891358+00	2f354786-d40a-40de-8c8c-cf197bb7f989	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
125	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	5	18	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-24 19:42:22.632983+00	7dd9b90a-d9ed-4964-8348-fb4d26dac580	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=eTLh1JuFqCM"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
126	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	5	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-24 19:42:42.1567+00	dd61514c-1f37-4f7c-bf45-15e27a7e4a74	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
127	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	5	15	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-24 19:50:46.365225+00	2c240675-669a-4b6f-8cc9-43cdebc35850	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
128	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	5	15	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-24 19:50:46.365225+00	2c240675-669a-4b6f-8cc9-43cdebc35850	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
129	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	5	15	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-24 19:50:46.365225+00	2c240675-669a-4b6f-8cc9-43cdebc35850	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
130	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	5	19	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-24 20:20:59.738326+00	6bf294c2-448c-4c55-8ca9-f28cc68885fe	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "http://192.168.0.57/neiva/bienvenida.php"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
131	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	5	15	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-24 20:21:17.350014+00	aab984b9-8705-4a0a-a85e-4ec1037b2563	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
132	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	4	25	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-27 14:52:04.695114+00	5a02d33e-28a0-43e7-98c3-ef2ca97f62ce	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=eTLh1JuFqCM"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
133	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	4	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-27 14:52:30.734897+00	e6a6df72-f923-4b0c-8a81-22a1de1dd46a	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
134	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	4	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 14:54:26.536533+00	daaaa502-0cff-4b7b-b1be-3d9376382974	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "16"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
135	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	4	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 14:54:26.536533+00	daaaa502-0cff-4b7b-b1be-3d9376382974	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "16"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
136	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	4	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 14:54:26.536533+00	daaaa502-0cff-4b7b-b1be-3d9376382974	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "16"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
137	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	4	16	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-27 14:55:29.039697+00	d05f0281-192b-41ac-9fd5-abbbb03bb14e	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://desarrolloarbimapps.atlassian.net/issues/?filter=-1"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
138	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	4	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-27 14:55:52.80797+00	05e75774-9119-4e2d-89a1-2e5f55616464	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
139	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	6	25	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-27 15:49:30.010348+00	f3f5b7d3-e435-4436-9079-588256404118	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=eTLh1JuFqCM"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
140	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	6	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-27 16:38:52.015338+00	29569ab2-7f14-4d59-8382-612d786ab0bd	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
141	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	6	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 16:39:16.122523+00	8867d09a-efcd-44e5-b687-9e383d43270a	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
142	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	6	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 16:39:16.122523+00	8867d09a-efcd-44e5-b687-9e383d43270a	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
143	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	6	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 16:39:16.122523+00	8867d09a-efcd-44e5-b687-9e383d43270a	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
144	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	7	25	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-27 20:05:08.568732+00	dcb9f522-23c4-4a6e-aa2d-053676f38f83	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://github.com/MasterErrorCLONE04/Arbimaps_rework"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
145	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	7	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-27 20:05:47.64866+00	a12c7542-b866-416e-85c9-bde0cdeea083	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
146	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	7	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 20:06:11.622698+00	b527b22b-6a7b-469e-b4b4-96c447ce1dd1	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
147	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	7	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 20:06:11.622698+00	b527b22b-6a7b-469e-b4b4-96c447ce1dd1	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
148	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	7	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 20:06:11.622698+00	b527b22b-6a7b-469e-b4b4-96c447ce1dd1	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
149	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	8	25	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-27 20:51:36.164678+00	26d0872f-8990-448d-aef2-0ddb87669132	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://www.youtube.com/watch?v=ith_yAAZqrk"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
150	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	8	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-27 20:52:10.672497+00	8ed538c2-7080-472d-80c0-4a7f59542a75	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
151	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	8	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 20:52:32.065386+00	57405d28-50c8-49c6-8fa9-338dcfa24b75	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
152	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	8	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 20:52:32.065386+00	57405d28-50c8-49c6-8fa9-338dcfa24b75	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
153	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	8	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-27 20:52:32.065386+00	57405d28-50c8-49c6-8fa9-338dcfa24b75	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
154	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	8	19	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-27 20:53:25.204343+00	ad88aa11-704d-44cf-84a5-031f045308c8	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://github.com/MasterErrorCLONE04/Arbimaps_rework"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
155	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	8	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-27 20:53:46.803652+00	a2603014-3e3e-424e-816a-bf5c5f25c412	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
156	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	10	25	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-28 15:17:48.289005+00	04c866e6-382a-485b-9e21-8fcc58eb1778	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://github.com/MasterErrorCLONE04/Develop"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
157	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	10	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-28 15:18:04.488346+00	cf9e0d35-6c47-4cf4-861d-96e78ffd8721	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
158	AuditEventType.ASSIGNMENT_REASSIGNED	sucre	10	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-28 15:18:20.364807+00	5d4779e3-2bfe-4c1c-bac1-9ba2f6c300c2	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
159	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	10	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-28 15:18:20.364807+00	5d4779e3-2bfe-4c1c-bac1-9ba2f6c300c2	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
160	AuditEventType.ASSIGNMENT_WORKSPACE_BUILD_REQUESTED	sucre	10	1	coordinador	REASSIGN	APROBACION	EN_CAMPO	2026-07-28 15:18:20.364807+00	5d4779e3-2bfe-4c1c-bac1-9ba2f6c300c2	workflow.service	{"precondition_hooks": ["validate_target_user"], "transition_metadata": {"target_user_id": "19"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
161	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	10	19	reconocedor	SUBMIT_FOR_QA	EN_CAMPO	CONTROL_CALIDAD_1	2026-07-28 15:18:45.499047+00	f42a8aeb-12c3-45ee-ac2e-387a270b48c7	workflow.service	{"precondition_hooks": ["workspace_ready", "owner_check"], "transition_metadata": {"enlace_control_calidad": "https://desarrolloarbimapps.atlassian.net/issues/?filter=-1"}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
162	AuditEventType.ASSIGNMENT_WORKFLOW_CHANGED	sucre	10	1	coordinador	APPROVE	CONTROL_CALIDAD_1	APROBACION	2026-07-28 15:19:12.731262+00	f56bff5d-dd19-46ef-88d0-eda2b71633de	workflow.service	{"precondition_hooks": ["workspace_ready"], "transition_metadata": {}, "audit_context_metadata": {}, "post_transition_events": ["assignment.workflow.changed"]}
\.


--
-- Data for Name: outbox_messages; Type: TABLE DATA; Schema: d_workflow; Owner: postgres
--

COPY d_workflow.outbox_messages (id, job_type, tenant_code, assignment_id, correlation_id, idempotency_key, payload, status, attempt_count, next_attempt_at, last_error, created_at, processed_at) FROM stdin;
1	BUILD_WORKSPACE	sucre	146	a2a5a363-8ef0-4c4e-af04-9171764e9e70	sucre:146:6:BUILD_WORKSPACE	{"metadata": {"target_user_id": "16"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "15", "assignment_id": "146", "correlation_id": "a2a5a363-8ef0-4c4e-af04-9171764e9e70", "workflow_event": "REASSIGN", "workflow_state": "APROBACION"}	PENDING	0	\N	\N	2026-06-09 12:49:05.322609+00	\N
2	BUILD_WORKSPACE	sucre	147	7d2b0350-187d-417b-800f-10cd37ff1de7	sucre:147:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "18"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "15", "assignment_id": "147", "correlation_id": "7d2b0350-187d-417b-800f-10cd37ff1de7", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-09 14:31:59.428356+00	\N
3	SYNC_ASSIGNMENT	sucre	147	2223df37-f17b-49fb-8ee0-9778b763dbed	sucre:147:12:SYNC_ASSIGNMENT	{"metadata": {}, "actor_role": "lider", "tenant_code": "sucre", "actor_user_id": "2", "assignment_id": "147", "correlation_id": "2223df37-f17b-49fb-8ee0-9778b763dbed", "workflow_event": "START_SYNC", "workflow_state": "SINCRONIZACION"}	PENDING	0	\N	\N	2026-06-09 17:53:18.440951+00	\N
4	BUILD_WORKSPACE	sucre	148	b9e36711-ec64-48b6-8856-d10ed2a97432	sucre:148:6:BUILD_WORKSPACE	{"metadata": {"target_user_id": "6"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "148", "correlation_id": "b9e36711-ec64-48b6-8856-d10ed2a97432", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-09 18:51:30.502783+00	\N
5	BUILD_WORKSPACE	sucre	148	21873b9c-afed-4358-9f06-70af5c034586	sucre:148:8:BUILD_WORKSPACE	{"metadata": {"target_user_id": "6"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "148", "correlation_id": "21873b9c-afed-4358-9f06-70af5c034586", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-09 19:08:04.880918+00	\N
6	SYNC_ASSIGNMENT	sucre	148	8c2b0e4e-a9bc-4e7a-90a8-0faecb6f1eda	sucre:148:27:SYNC_ASSIGNMENT	{"metadata": {}, "actor_role": "lider", "tenant_code": "sucre", "actor_user_id": "2", "assignment_id": "148", "correlation_id": "8c2b0e4e-a9bc-4e7a-90a8-0faecb6f1eda", "workflow_event": "START_SYNC", "workflow_state": "SINCRONIZACION"}	PENDING	0	\N	\N	2026-06-09 20:07:28.789737+00	\N
7	BUILD_WORKSPACE	sucre	149	b921d348-c65e-4668-805a-408e54ef20c2	sucre:149:6:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "149", "correlation_id": "b921d348-c65e-4668-805a-408e54ef20c2", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-09 20:46:52.951939+00	\N
8	SYNC_ASSIGNMENT	sucre	149	e12c74ba-fe35-4452-a28b-a5a12969c6ec	sucre:149:15:SYNC_ASSIGNMENT	{"metadata": {}, "actor_role": "lider", "tenant_code": "sucre", "actor_user_id": "2", "assignment_id": "149", "correlation_id": "e12c74ba-fe35-4452-a28b-a5a12969c6ec", "workflow_event": "START_SYNC", "workflow_state": "SINCRONIZACION"}	PENDING	0	\N	\N	2026-06-09 20:49:34.784748+00	\N
9	BUILD_WORKSPACE	sucre	156	5a34acfa-a95a-49c7-b525-21fb4a237865	sucre:156:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "6"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "156", "correlation_id": "5a34acfa-a95a-49c7-b525-21fb4a237865", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-10 19:18:29.827752+00	\N
10	SYNC_ASSIGNMENT	sucre	156	7cd4b866-cf11-4073-ba49-b5c67b324b79	sucre:156:8:SYNC_ASSIGNMENT	{"metadata": {}, "actor_role": "lider", "tenant_code": "sucre", "actor_user_id": "2", "assignment_id": "156", "correlation_id": "7cd4b866-cf11-4073-ba49-b5c67b324b79", "workflow_event": "START_SYNC", "workflow_state": "SINCRONIZACION"}	PENDING	0	\N	\N	2026-06-10 19:20:29.98759+00	\N
11	BUILD_WORKSPACE	sucre	157	8a274f32-77c2-4437-b20e-0bd69f548756	sucre:157:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "6"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "157", "correlation_id": "8a274f32-77c2-4437-b20e-0bd69f548756", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-10 21:55:19.111143+00	\N
12	SYNC_ASSIGNMENT	sucre	157	88e51a11-f71d-4f92-895a-2a146ebf4d97	sucre:157:8:SYNC_ASSIGNMENT	{"metadata": {}, "actor_role": "lider", "tenant_code": "sucre", "actor_user_id": "2", "assignment_id": "157", "correlation_id": "88e51a11-f71d-4f92-895a-2a146ebf4d97", "workflow_event": "START_SYNC", "workflow_state": "SINCRONIZACION"}	PENDING	0	\N	\N	2026-06-10 21:56:15.112405+00	\N
13	BUILD_WORKSPACE	sucre	158	87e0a035-9d3a-4241-8cc9-c4c33514884e	sucre:158:8:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "158", "correlation_id": "87e0a035-9d3a-4241-8cc9-c4c33514884e", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-12 15:57:48.127234+00	\N
14	SYNC_ASSIGNMENT	sucre	158	2d57d24e-5717-455f-b361-c025527a8ff2	sucre:158:18:SYNC_ASSIGNMENT	{"metadata": {}, "actor_role": "lider", "tenant_code": "sucre", "actor_user_id": "2", "assignment_id": "158", "correlation_id": "2d57d24e-5717-455f-b361-c025527a8ff2", "workflow_event": "START_SYNC", "workflow_state": "SINCRONIZACION"}	PENDING	0	\N	\N	2026-06-12 18:47:34.715814+00	\N
15	BUILD_WORKSPACE	sucre	159	5367e0e2-e78a-4c02-b09d-d8f587baf431	sucre:159:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "6"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "159", "correlation_id": "5367e0e2-e78a-4c02-b09d-d8f587baf431", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-06-16 13:58:58.936901+00	\N
16	BUILD_WORKSPACE	sucre	3	374ab00f-c262-46ad-b9c5-1ae060707715	sucre:3:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "9", "assignment_id": "3", "correlation_id": "374ab00f-c262-46ad-b9c5-1ae060707715", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-07-24 15:47:56.511903+00	\N
17	BUILD_WORKSPACE	sucre	5	2c240675-669a-4b6f-8cc9-43cdebc35850	sucre:5:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "15", "assignment_id": "5", "correlation_id": "2c240675-669a-4b6f-8cc9-43cdebc35850", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-07-24 19:50:46.363596+00	\N
18	BUILD_WORKSPACE	sucre	4	daaaa502-0cff-4b7b-b1be-3d9376382974	sucre:4:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "16"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "1", "assignment_id": "4", "correlation_id": "daaaa502-0cff-4b7b-b1be-3d9376382974", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-07-27 14:54:26.535724+00	\N
19	BUILD_WORKSPACE	sucre	6	8867d09a-efcd-44e5-b687-9e383d43270a	sucre:6:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "1", "assignment_id": "6", "correlation_id": "8867d09a-efcd-44e5-b687-9e383d43270a", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-07-27 16:39:16.121753+00	\N
20	BUILD_WORKSPACE	sucre	7	b527b22b-6a7b-469e-b4b4-96c447ce1dd1	sucre:7:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "1", "assignment_id": "7", "correlation_id": "b527b22b-6a7b-469e-b4b4-96c447ce1dd1", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-07-27 20:06:11.621977+00	\N
21	BUILD_WORKSPACE	sucre	8	57405d28-50c8-49c6-8fa9-338dcfa24b75	sucre:8:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "1", "assignment_id": "8", "correlation_id": "57405d28-50c8-49c6-8fa9-338dcfa24b75", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-07-27 20:52:32.064627+00	\N
22	BUILD_WORKSPACE	sucre	10	5d4779e3-2bfe-4c1c-bac1-9ba2f6c300c2	sucre:10:4:BUILD_WORKSPACE	{"metadata": {"target_user_id": "19"}, "actor_role": "coordinador", "tenant_code": "sucre", "actor_user_id": "1", "assignment_id": "10", "correlation_id": "5d4779e3-2bfe-4c1c-bac1-9ba2f6c300c2", "workflow_event": "REASSIGN", "workflow_state": "EN_CAMPO"}	PENDING	0	\N	\N	2026-07-28 15:18:20.364284+00	\N
\.


--
-- Name: assignment_retorno_id_seq; Type: SEQUENCE SET; Schema: d_workflow; Owner: postgres
--

SELECT pg_catalog.setval('d_workflow.assignment_retorno_id_seq', 1, false);


--
-- Name: assignment_sync_job_id_seq; Type: SEQUENCE SET; Schema: d_workflow; Owner: postgres
--

SELECT pg_catalog.setval('d_workflow.assignment_sync_job_id_seq', 1, false);


--
-- Name: assignment_transitions_id_seq; Type: SEQUENCE SET; Schema: d_workflow; Owner: postgres
--

SELECT pg_catalog.setval('d_workflow.assignment_transitions_id_seq', 128, true);


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: d_workflow; Owner: postgres
--

SELECT pg_catalog.setval('d_workflow.audit_events_id_seq', 162, true);


--
-- Name: outbox_messages_id_seq; Type: SEQUENCE SET; Schema: d_workflow; Owner: postgres
--

SELECT pg_catalog.setval('d_workflow.outbox_messages_id_seq', 22, true);


--
-- Name: assignment_retorno assignment_retorno_pkey; Type: CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_retorno
    ADD CONSTRAINT assignment_retorno_pkey PRIMARY KEY (id);


--
-- Name: assignment_sync_job assignment_sync_job_pkey; Type: CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_sync_job
    ADD CONSTRAINT assignment_sync_job_pkey PRIMARY KEY (id);


--
-- Name: assignment_transitions assignment_transitions_pkey; Type: CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_transitions
    ADD CONSTRAINT assignment_transitions_pkey PRIMARY KEY (id);


--
-- Name: assignments assignments_pkey; Type: CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY (tenant_code, assignment_id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: outbox_messages outbox_messages_pkey; Type: CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.outbox_messages
    ADD CONSTRAINT outbox_messages_pkey PRIMARY KEY (id);


--
-- Name: outbox_messages uq_outbox_idempotency; Type: CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.outbox_messages
    ADD CONSTRAINT uq_outbox_idempotency UNIQUE (idempotency_key);


--
-- Name: idx_assignment_retorno_file_hash; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignment_retorno_file_hash ON d_workflow.assignment_retorno USING btree (file_hash);


--
-- Name: idx_assignment_retorno_tenant_assignment; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignment_retorno_tenant_assignment ON d_workflow.assignment_retorno USING btree (tenant_code, assignment_id);


--
-- Name: idx_assignment_sync_job_created_at; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignment_sync_job_created_at ON d_workflow.assignment_sync_job USING btree (created_at);


--
-- Name: idx_assignment_sync_job_state; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignment_sync_job_state ON d_workflow.assignment_sync_job USING btree (sync_state);


--
-- Name: idx_assignment_sync_job_tenant_assignment; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignment_sync_job_tenant_assignment ON d_workflow.assignment_sync_job USING btree (tenant_code, assignment_id);


--
-- Name: idx_assignment_transitions_occurred_at; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignment_transitions_occurred_at ON d_workflow.assignment_transitions USING btree (occurred_at);


--
-- Name: idx_assignment_transitions_tenant_assignment; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignment_transitions_tenant_assignment ON d_workflow.assignment_transitions USING btree (tenant_code, assignment_id);


--
-- Name: idx_assignments_assigned_user_id; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignments_assigned_user_id ON d_workflow.assignments USING btree (assigned_user_id);


--
-- Name: idx_assignments_sync_state; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignments_sync_state ON d_workflow.assignments USING btree (sync_state);


--
-- Name: idx_assignments_updated_at; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignments_updated_at ON d_workflow.assignments USING btree (updated_at);


--
-- Name: idx_assignments_workflow_state; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_assignments_workflow_state ON d_workflow.assignments USING btree (workflow_state);


--
-- Name: idx_audit_events_assignment_id; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_audit_events_assignment_id ON d_workflow.audit_events USING btree (assignment_id);


--
-- Name: idx_audit_events_correlation_id; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_audit_events_correlation_id ON d_workflow.audit_events USING btree (correlation_id);


--
-- Name: idx_audit_events_occurred_at; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_audit_events_occurred_at ON d_workflow.audit_events USING btree (occurred_at);


--
-- Name: idx_audit_events_tenant_assignment; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_audit_events_tenant_assignment ON d_workflow.audit_events USING btree (tenant_code, assignment_id);


--
-- Name: idx_outbox_messages_created_at; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_outbox_messages_created_at ON d_workflow.outbox_messages USING btree (created_at);


--
-- Name: idx_outbox_messages_next_attempt_at; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_outbox_messages_next_attempt_at ON d_workflow.outbox_messages USING btree (next_attempt_at);


--
-- Name: idx_outbox_messages_status; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_outbox_messages_status ON d_workflow.outbox_messages USING btree (status);


--
-- Name: idx_outbox_messages_tenant_assignment; Type: INDEX; Schema: d_workflow; Owner: postgres
--

CREATE INDEX idx_outbox_messages_tenant_assignment ON d_workflow.outbox_messages USING btree (tenant_code, assignment_id);


--
-- Name: assignment_retorno fk_assignment_retorno_assignment; Type: FK CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_retorno
    ADD CONSTRAINT fk_assignment_retorno_assignment FOREIGN KEY (tenant_code, assignment_id) REFERENCES d_workflow.assignments(tenant_code, assignment_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: assignment_sync_job fk_assignment_sync_job_assignment; Type: FK CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_sync_job
    ADD CONSTRAINT fk_assignment_sync_job_assignment FOREIGN KEY (tenant_code, assignment_id) REFERENCES d_workflow.assignments(tenant_code, assignment_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: assignment_transitions fk_assignment_transitions_assignment; Type: FK CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.assignment_transitions
    ADD CONSTRAINT fk_assignment_transitions_assignment FOREIGN KEY (tenant_code, assignment_id) REFERENCES d_workflow.assignments(tenant_code, assignment_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audit_events fk_audit_events_assignment; Type: FK CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.audit_events
    ADD CONSTRAINT fk_audit_events_assignment FOREIGN KEY (tenant_code, assignment_id) REFERENCES d_workflow.assignments(tenant_code, assignment_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: outbox_messages fk_outbox_messages_assignment; Type: FK CONSTRAINT; Schema: d_workflow; Owner: postgres
--

ALTER TABLE ONLY d_workflow.outbox_messages
    ADD CONSTRAINT fk_outbox_messages_assignment FOREIGN KEY (tenant_code, assignment_id) REFERENCES d_workflow.assignments(tenant_code, assignment_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

